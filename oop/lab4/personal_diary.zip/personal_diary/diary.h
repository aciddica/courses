#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
#include<fstream>
using namespace std;
class Diary //the diary class
{
    public:
    string date;
    vector<string> text; //store different lines of texts
};
